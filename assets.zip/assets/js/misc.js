$(function(){
    
    $(document).ready(function(){

        var bg = randomColor(); // a hex code for an attractive color
        
        if (wallpaper === true) {
            $(".bg").css("background-image", "url('https://i.imgur.com/k6rGqo6.jpg')");
        
           $(".bg").css("background-size","cover");
        } else {
           $(".bg").css("background-color",bg);
        }
            
    
        var wallpaper
        
    $('#wallpaper-on').click(function(){
           $(".bg").css("background-image", "url('https://i.imgur.com/k6rGqo6.jpg')");
        
           $(".bg").css("background-size","cover");

            var wallpaper = true;
            localStorage.setItem("wallpaper",JSON.stringify(wallpaper));
    })
    
    $("#wallpaper-off").click(function(){
        $(".bg").css("background-image","");
        
        var wallpaper = false;
    })
    
    $("#save-settings").click(function(){
        
        localStorage.setItem("wallpaper",JSON.stringify(wallpaper));
        
    });
            
        })})