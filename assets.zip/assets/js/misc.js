$(function(){
    
    $(document).ready(function(){

     var bg = Math.floor((Math.random() * 9) + 1);   
        
        if(bg === 1){
            $(".bg").css("background-color","#cec2ff");
        } 
        
        if(bg === 2){
            $(".bg").css("background-color","#b3b3f1");
        }
        
        if(bg === 3){
            $(".bg").css("background-color","#dcb6d5");
        }
        
        if(bg === 4){
            $(".bg").css("background-color","#cf8ba9");
        }
        
        if(bg === 5){
            $(".bg").css("background-color","#b15e6c");
        }
        
        if(bg === 6){
            $(".bg").css("background-color","#8aa399");
        }
        
        if(bg === 7){
            $(".bg").css("background-color","#7d84b2");
        }
        
        if(bg === 8){
            $(".bg").css("background-color","#dbf4a7");
        }
        
        if(bg === 9){
            $(".bg").css("background-color","#d5f9de");
        }
            
        
});
    
    
    $('#wallpaper-on').click(function(){
           $(".bg").css("background-image", "url('https://i.imgur.com/k6rGqo6.jpg')");
        
           $(".bg").css("background-size","cover");
        
            var wallpaper = true;
    })
    
    $("#wallpaper-off").click(function(){
        $(".bg").css("background-image","");
        
        var wallpaper = false;
    })
    
    $("#save").click(function(){
        
        localStorage.setItem
        
    })
})